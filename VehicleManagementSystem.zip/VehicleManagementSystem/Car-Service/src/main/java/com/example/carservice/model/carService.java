package com.example.carservice.model;

public class carService {
	private Long id;
    private String make;
    private String model;
    private int year;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }
}

/*Car-Servive interface:

package com.example.carservice.service;

import com.example.carservice.model.Car;
import java.util.List;

public interface CarService {
    Car addCar(Car car);
    Car getCarById(Long id);
    List<Car> getAllCars();
    Car updateCar(Long id, Car car);
    void deleteCar(Long id);
}
Implementation class

package com.example.carservice.service;

import com.example.carservice.model.Car;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class CarServiceImpl implements CarService {
    private final List<Car> cars = new ArrayList<>();

    @Override
    public Car addCar(Car car) {
        cars.add(car);
        return car;
    }

    @Override
    public Car getCarById(Long id) {
        return cars.stream().filter(car -> car.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Car> getAllCars() {
        return cars;
    }

    @Override
    public Car updateCar(Long id, Car car) {
        Car existingCar = getCarById(id);
        if (existingCar != null) {
            existingCar.setMake(car.getMake());
            existingCar.setModel(car.getModel());
            existingCar.setYear(car.getYear());
        }
        return existingCar;
    }

    @Override
    public void deleteCar(Long id) {
        cars.removeIf(car -> car.getId().equals(id));
    }

}*/

package org.Car.Service;
import com.example.CarService.model
import com.example.carservice.model.carService;

import java.util.List;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public interface CarInterface {
	 	carService addCar(carService car);
	 	carService getCarById(Long id);
	    List<carService> getAllCars();
	    carService updateCar(Long id, carService car);
	    void deleteCar(Long id);
}



package org.Car.Service;



public class CarServiceImpl implements carService {
    private final List<Car> cars = new ArrayList<>();

    @Override
    public carService addCar(carService car) {
        cars.add(car);
        return car;
    }

    @Override
    public Car getCarById(Long id) {
        return cars.stream().filter(car -> car.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Car> getAllCars() {
        return cars;
    }

    @Override
    public Car updateCar(Long id, Car car) {
        Car existingCar = getCarById(id);
        if (existingCar != null) {
            existingCar.setMake(car.getMake());
            existingCar.setModel(car.getModel());
            existingCar.setYear(car.getYear());
        }
        return existingCar;
    }

    @Override
    public void deleteCar(Long id) {
        cars.removeIf(car -> car.getId().equals(id));
    }
}

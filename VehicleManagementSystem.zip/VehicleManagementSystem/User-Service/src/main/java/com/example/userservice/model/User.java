package com.example.userservice.model;

public record User() {

}

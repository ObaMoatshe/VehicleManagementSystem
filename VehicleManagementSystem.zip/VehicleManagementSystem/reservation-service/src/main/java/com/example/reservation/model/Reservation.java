package com.example.reservation.model;

import java.time.LocalDateTime;

public class Reservation {
    private Long id;
    private Long userId;
    private Long vehicleId;
    private LocalDateTime reservationDate;
    private LocalDateTime returnDate;

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public Long getVehicleId() {
        return vehicleId;
    }

    public void setVehicleId(Long vehicleId) {
        this.vehicleId = vehicleId;
    }

    public LocalDateTime getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(LocalDateTime reservationDate) {
        this.reservationDate = reservationDate;
    }

    public LocalDateTime getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }
}
INTERFACE - MANAGE RESERVATIONS
package com.example.reservationservice.service;

import com.example.reservationservice.model.Reservation;
import java.util.List;

public interface ReservationService {
    Reservation createReservation(Reservation reservation);
    Reservation getReservationById(Long id);
    List<Reservation> getAllReservations();
    Reservation updateReservation(Long id, Reservation reservation);
    void deleteReservation(Long id);
}

IMPLEMENTOR CLASS
package com.example.reservationservice.service;

import com.example.reservationservice.model.Reservation;
import java.util.ArrayList;
import java.util.List;

public class ReservationServiceImpl implements ReservationService {
    private final List<Reservation> reservations = new ArrayList<>();

    @Override
    public Reservation createReservation(Reservation reservation) {
        reservations.add(reservation);
        return reservation;
    }

    @Override
    public Reservation getReservationById(Long id) {
        return reservations.stream().filter(r -> r.getId().equals(id)).findFirst().orElse(null);
    }

    @Override
    public List<Reservation> getAllReservations() {
        return reservations;
    }

    @Override
    public Reservation updateReservation(Long id, Reservation reservation) {
        Reservation existingReservation = getReservationById(id);
        if (existingReservation != null) {
            existingReservation.setUserId(reservation.getUserId());
            existingReservation.setVehicleId(reservation.getVehicleId());
            existingReservation.setReservationDate(reservation.getReservationDate());
            existingReservation.setReturnDate(reservation.getReturnDate());
        }
        return existingReservation;
    }

    @Override
    public void deleteReservation(Long id) {
        reservations.removeIf(r -> r.getId().equals(id));
    }
}
REST CONTROLLER FOR HTTP REQUESTS
package com.example.reservationservice.controller;

import com.example.reservationservice.model.Reservation;
import com.example.reservationservice.service.ReservationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/reservations")
public class ReservationController {

    private final ReservationService reservationService;

    @Autowired
    public ReservationController(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @PostMapping
    public Reservation createReservation(@RequestBody Reservation reservation) {
        return reservationService.createReservation(reservation);
    }

    @GetMapping("/{id}")
    public Reservation getReservationById(@PathVariable Long id) {
        return reservationService.getReservationById(id);
    }

    @GetMapping
    public List<Reservation> getAllReservations() {
        return reservationService.getAllReservations();
    }

    @PutMapping("/{id}")
    public Reservation updateReservation(@PathVariable Long id, @RequestBody Reservation reservation) {
        return reservationService.updateReservation(id, reservation);
    }

    @DeleteMapping("/{id}")
    public void deleteReservation(@PathVariable Long id) {
        reservationService.deleteReservation(id);
    }
}